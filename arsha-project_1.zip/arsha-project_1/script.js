var prevScrollpos = window.scrollY;
        window.onscroll = function () {
            var currentScrollPos = window.scrollY;
            if (prevScrollpos > currentScrollPos) {
                document.getElementById("hide").style.top = "0";
            } else {
                document.getElementById("hide").style.top = "-60px";
            }
            prevScrollpos = currentScrollPos;
        }